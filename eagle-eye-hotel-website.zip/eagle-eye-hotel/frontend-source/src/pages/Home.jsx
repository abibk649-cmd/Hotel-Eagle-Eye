import { useEffect } from "react";
import { Link } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight, ArrowDown, Star, BedDouble, ShowerHead, Sofa, Wifi,
  MapPin, Phone, MessageCircle, ExternalLink,
} from "lucide-react";
import { PageHero } from "../components/PageHero";
import { Reveal, Stagger, StaggerItem } from "../components/Reveal";
import { ReviewCard } from "../components/ReviewCard";
import { ImageWithFallback } from "../components/ImageWithFallback";
import { Marquee } from "../components/Marquee";
import { FAQ } from "../components/FAQ";
import { LocationSection } from "../components/LocationSection";
import { CTASection } from "../components/CTASection";
import {
  site, stayFeatures, rooms, mealMoments, whyFeatures, routeStops,
  galleryImages, faqs, imagery, verifiedReviews,
} from "../data/siteData";

const featureIcons = { bed: BedDouble, shower: ShowerHead, sofa: Sofa, wifi: Wifi };

const TrustStrip = () => (
  <section className="border-b border-[#173F35]/10 bg-white" data-testid="trust-strip">
    <div className="container-ee grid grid-cols-1 divide-y divide-[#173F35]/10 sm:grid-cols-3 sm:divide-x sm:divide-y-0">
      <div className="flex items-center justify-center gap-3 py-5">
        <Star className="h-5 w-5 fill-[#C88A3D] text-[#C88A3D]" aria-hidden="true" />
        <p className="text-sm text-[#17201F]">
          <span className="font-semibold" data-testid="trust-rating">{site.rating}/5</span>{" "}
          <span className="text-[#687572]">on Google · <span data-testid="trust-review-count">{site.reviewCount}</span> reviews</span>
        </p>
      </div>
      <div className="flex items-center justify-center gap-2 py-5 text-sm text-[#17201F]">
        <MapPin className="h-4 w-4 text-[#C88A3D]" aria-hidden="true" />
        <span className="font-medium">{site.area}</span>
      </div>
      <div className="flex items-center justify-center gap-2 py-5 text-sm text-[#17201F]">
        <BedDouble className="h-4 w-4 text-[#C88A3D]" aria-hidden="true" />
        <span className="font-medium">{site.category}</span>
      </div>
    </div>
  </section>
);

const SectionHead = ({ eyebrow, title, copy, center = false }) => (
  <Reveal className={center ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
    <p className="eyebrow">{eyebrow}</p>
    <h2 className="font-display mt-3 text-4xl leading-[1.08] text-[#17201F] sm:text-5xl">{title}</h2>
    {copy && <p className="mt-5 text-base leading-relaxed text-[#687572] sm:text-lg">{copy}</p>}
  </Reveal>
);

const Home = () => {
  const reduce = useReducedMotion();

  useEffect(() => {
    document.title = "Eagle Eye Hotel Chame | Hotel & Restaurant in Manang";
    if (window.location.hash === "#about") {
      setTimeout(() => document.getElementById("about")?.scrollIntoView({ behavior: reduce ? "auto" : "smooth" }), 200);
    }
  }, [reduce]);

  return (
    <>
      {/* HERO */}
      <PageHero
        image={imagery.heroHome}
        alt={imagery.heroHomeAlt}
        eyebrow="Eagle Eye Hotel · Chame, Manang"
        lines={["Rest Well.", "Eat Well.", "Wake Up to the Himalayas."]}
        fullHeight
      >
        <p className="max-w-xl text-base leading-relaxed text-[#F7F5F0]/85 sm:text-lg" data-testid="hero-subtext">
          Welcome to Eagle Eye Hotel in Chame, Manang — a warm mountain stay for
          trekkers and travelers exploring the Annapurna Circuit.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Link to="/contact" className="btn-amber" data-testid="hero-book-cta">
            Book Your Stay <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>
          <a href="#about" className="btn-ghost text-white hover:bg-white/10" data-testid="hero-explore-cta">
            Explore Eagle Eye <ArrowDown className="h-4 w-4" aria-hidden="true" />
          </a>
        </div>
      </PageHero>

      <TrustStrip />

      {/* INTRO / ABOUT */}
      <section id="about" className="py-24 sm:py-32" data-testid="intro-section">
        <div className="container-ee grid items-center gap-12 lg:grid-cols-12">
          <Reveal className="lg:col-span-5">
            <p className="eyebrow">01 — Welcome</p>
            <h2 className="font-display mt-3 text-4xl leading-[1.08] text-[#17201F] sm:text-5xl">
              Your Mountain Home in Chame
            </h2>
            <p className="mt-6 text-base leading-relaxed text-[#687572] sm:text-lg">
              After a long day on the trail, comfort matters. Eagle Eye Hotel offers a
              welcoming place to rest, enjoy a good meal and take in the mountain
              surroundings of Chame.
            </p>
            <Link to="/stay" className="btn-primary mt-8" data-testid="intro-discover-cta">
              Discover Your Stay <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </Reveal>
          <Reveal delay={0.15} className="lg:col-span-7 lg:pl-8">
            <div className="relative">
              <div className="overflow-hidden rounded-2xl">
                <motion.div
                  whileHover={reduce ? undefined : { scale: 1.03 }}
                  transition={{ duration: 0.6 }}
                >
                  <ImageWithFallback
                    src={imagery.intro}
                    alt={imagery.introAlt}
                    className="aspect-[4/3] w-full object-cover"
                  />
                </motion.div>
              </div>
              <div className="absolute -bottom-6 -left-4 hidden rounded-2xl bg-[#E9D7B8] px-6 py-4 sm:block" data-testid="intro-badge">
                <p className="font-display text-lg leading-tight text-[#17201F]">Annapurna Circuit</p>
                <p className="text-xs font-medium uppercase tracking-[0.2em] text-[#687572]">Chame · Manang · Nepal</p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* STAY */}
      <section className="bg-white py-24 sm:py-32" data-testid="stay-section">
        <div className="container-ee">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <SectionHead
              eyebrow="02 — Stay"
              title="A Comfortable Stop Along the Trail"
            />
            <Reveal delay={0.1}>
              <Link to="/stay" className="btn-ghost text-[#173F35]" data-testid="stay-explore-cta">
                Explore Your Stay <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </Reveal>
          </div>
          <Stagger className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {stayFeatures.map((f) => {
              const Icon = featureIcons[f.icon] || BedDouble;
              return (
                <StaggerItem key={f.title}>
                  <div className="card-ee h-full p-7" data-testid={`stay-feature-${f.icon}`}>
                    <Icon className="h-7 w-7 text-[#C88A3D]" aria-hidden="true" />
                    <h3 className="font-display mt-5 text-xl text-[#17201F]">{f.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-[#687572]">{f.text}</p>
                  </div>
                </StaggerItem>
              );
            })}
          </Stagger>
          <Stagger className="mt-5 grid gap-5 md:grid-cols-3">
            {rooms.map((r, i) => (
              <StaggerItem key={r.name}>
                <Link
                  to="/stay"
                  className="group block overflow-hidden rounded-2xl"
                  data-testid={`room-teaser-${i}`}
                >
                  <div className="relative overflow-hidden">
                    <ImageWithFallback
                      src={r.image}
                      alt={r.alt}
                      className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <span className="absolute bottom-4 left-4 rounded-full bg-[#0F3028]/85 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.16em] text-white backdrop-blur">
                      {r.name}
                    </span>
                  </div>
                </Link>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* RESTAURANT */}
      <section className="py-24 sm:py-32" data-testid="restaurant-section">
        <div className="container-ee grid items-start gap-12 lg:grid-cols-12">
          <div className="lg:sticky lg:top-28 lg:col-span-4">
            <SectionHead
              eyebrow="03 — Eat"
              title="Good Food for the Trail Ahead"
              copy="Start your day with breakfast, settle in for a warm meal after the trail, or enjoy a coffee and something freshly baked."
            />
            <Reveal delay={0.15}>
              <Link to="/restaurant" className="btn-primary mt-8" data-testid="restaurant-explore-cta">
                Explore Restaurant <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </Reveal>
          </div>
          <Stagger className="grid gap-5 sm:grid-cols-2 lg:col-span-8">
            {mealMoments.map((m, i) => (
              <StaggerItem key={m.title} className={i === 0 ? "sm:col-span-2" : ""}>
                <div className="card-ee group overflow-hidden" data-testid={`meal-card-${m.title.toLowerCase().replace(/\s/g, "-")}`}>
                  <div className="overflow-hidden">
                    <ImageWithFallback
                      src={m.image}
                      alt={m.alt}
                      className={`${i === 0 ? "aspect-[21/9]" : "aspect-[16/9]"} w-full object-cover transition-transform duration-700 group-hover:scale-105`}
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="font-display text-xl text-[#17201F]">{m.title}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-[#687572]">{m.text}</p>
                  </div>
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* WHY */}
      <section className="grain relative bg-[#40545A] py-24 text-white sm:py-32" data-testid="why-section">
        <div className="container-ee">
          <SectionHead eyebrow="04 — Why Eagle Eye" title="More Than a Place to Sleep" />
          <Stagger className="mt-14 grid gap-px overflow-hidden rounded-2xl bg-white/15 sm:grid-cols-2 lg:grid-cols-4">
            {whyFeatures.map((f) => (
              <StaggerItem key={f.n} className="bg-[#40545A]">
                <div className="h-full p-8 transition-colors duration-300 hover:bg-[#37484e]" data-testid={`why-card-${f.n}`}>
                  <span className="font-display text-sm text-[#C88A3D]">{f.n}</span>
                  <h3 className="font-display mt-4 text-2xl text-white">{f.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-[#F7F5F0]/70">{f.text}</p>
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* ROUTE */}
      <section className="relative overflow-hidden py-24 sm:py-32" data-testid="route-section">
        <div className="absolute inset-0" aria-hidden="true">
          <ImageWithFallback src={imagery.route} alt="" className="h-full w-full object-cover opacity-[0.08]" />
        </div>
        <div className="container-ee relative">
          <SectionHead
            eyebrow="05 — The Trail"
            title="A Welcome Stop on Your Annapurna Journey"
            center
          />
          <Reveal delay={0.1} className="mt-14">
            <ol className="mx-auto flex max-w-4xl flex-col items-stretch gap-0 sm:flex-row sm:items-center" data-testid="route-stops">
              {routeStops.map((stop, i) => (
                <li key={stop} className="flex flex-1 items-center">
                  <div className={`flex flex-col items-center gap-2 px-2 text-center ${stop === "Chame" ? "" : "opacity-60"}`}>
                    <span
                      className={`flex h-12 w-12 items-center justify-center rounded-full border text-sm font-semibold ${
                        stop === "Chame"
                          ? "border-[#C88A3D] bg-[#C88A3D] text-[#17201F]"
                          : "border-[#173F35]/25 bg-white text-[#173F35]"
                      }`}
                    >
                      {i + 1}
                    </span>
                    <span className={`text-sm ${stop === "Chame" ? "font-semibold text-[#17201F]" : "font-medium text-[#40545A]"}`}>
                      {stop}
                    </span>
                  </div>
                  {i < routeStops.length - 1 && (
                    <span className="mx-1 hidden h-px flex-1 bg-[#173F35]/20 sm:block" aria-hidden="true" />
                  )}
                </li>
              ))}
            </ol>
          </Reveal>
          <Reveal delay={0.15} className="mt-12 text-center">
            <a href={site.googleMapsUrl} target="_blank" rel="noopener noreferrer" className="btn-primary" data-testid="route-find-us-cta">
              Find Us in Chame <MapPin className="h-4 w-4" aria-hidden="true" />
            </a>
          </Reveal>
        </div>
        <div className="mt-16">
          <Marquee items={["Dharapani", "Chame", "Pisang", "Manang", "Annapurna Circuit", "Eagle Eye Hotel"]} />
        </div>
      </section>

      {/* GALLERY PREVIEW */}
      <section className="bg-white py-24 sm:py-32" data-testid="gallery-preview-section">
        <div className="container-ee">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <SectionHead eyebrow="06 — Gallery" title="Moments from the Mountain" />
            <Reveal delay={0.1}>
              <Link to="/gallery" className="btn-ghost text-[#173F35]" data-testid="gallery-view-all-cta">
                View Full Gallery <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </Reveal>
          </div>
          <Stagger className="mt-14 grid grid-cols-2 gap-4 lg:grid-cols-4">
            {galleryImages.slice(0, 8).map((img, i) => (
              <StaggerItem key={img.src} className={i % 3 === 0 ? "row-span-2" : ""}>
                <Link to="/gallery" className="group block overflow-hidden rounded-2xl" data-testid={`gallery-preview-${i}`}>
                  <ImageWithFallback
                    src={img.src}
                    alt={img.alt}
                    className={`${i % 3 === 0 ? "aspect-[3/4] h-full" : "aspect-square"} w-full object-cover transition-transform duration-700 group-hover:scale-105`}
                  />
                </Link>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* REVIEWS */}
      <section className="py-24 sm:py-32" data-testid="reviews-section">
        <div className="container-ee">
          <SectionHead eyebrow="07 — Reviews" title="Loved by Travelers Along the Trail" center />
          {verifiedReviews.length > 0 ? (
            <>
              <Stagger className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-3" data-testid="reviews-grid">
                {verifiedReviews.map((r, i) => (
                  <StaggerItem key={`${r.name}-${i}`}>
                    <ReviewCard review={r} index={i} />
                  </StaggerItem>
                ))}
              </Stagger>
              <Reveal delay={0.1} className="mt-12 flex flex-col items-center gap-5 text-center">
                <p className="flex items-center gap-2 text-sm text-[#687572]">
                  <Star className="h-4 w-4 fill-[#C88A3D] text-[#C88A3D]" aria-hidden="true" />
                  <span>
                    <span className="font-semibold text-[#17201F]" data-testid="reviews-rating-value">{site.rating}/5</span>{" "}
                    on Google · <span data-testid="reviews-count-value">{site.reviewCount}</span> reviews
                  </span>
                </p>
                <a
                  href={site.googleReviewUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                  data-testid="read-more-reviews-button"
                >
                  Read More Reviews <ExternalLink className="h-4 w-4" aria-hidden="true" />
                </a>
              </Reveal>
            </>
          ) : (
            <Reveal delay={0.1} className="mx-auto mt-12 max-w-xl">
              <div className="card-ee p-10 text-center" data-testid="google-rating-card">
                <div className="flex items-center justify-center gap-1.5" aria-label={`Rated ${site.rating} out of 5`}>
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-6 w-6 fill-[#C88A3D] text-[#C88A3D]" aria-hidden="true" />
                  ))}
                </div>
                <p className="font-display mt-4 text-5xl text-[#17201F]" data-testid="reviews-rating-value">{site.rating}</p>
                <p className="mt-2 text-sm text-[#687572]">
                  Based on <span data-testid="reviews-count-value">{site.reviewCount}</span> Google reviews
                </p>
                <p className="mt-5 text-xs leading-relaxed text-[#687572]/80">
                  We only publish genuine, verifiable reviews. Individual review cards will
                  appear here once confirmed by the business.
                </p>
                <a
                  href={site.googleReviewUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary mt-7"
                  data-testid="read-more-reviews-button"
                >
                  Read More Reviews <ExternalLink className="h-4 w-4" aria-hidden="true" />
                </a>
              </div>
            </Reveal>
          )}
        </div>
      </section>

      <LocationSection />

      {/* FAQ */}
      <section className="py-24 sm:py-32" data-testid="faq-section">
        <div className="container-ee grid gap-12 lg:grid-cols-12">
          <Reveal className="lg:col-span-4">
            <p className="eyebrow">08 — FAQ</p>
            <h2 className="font-display mt-3 text-4xl leading-[1.08] text-[#17201F] sm:text-5xl">
              Good to Know
            </h2>
            <p className="mt-5 text-base text-[#687572]">
              Quick answers for travelers passing through Chame. Still unsure?{" "}
              <a href={site.phoneHref} className="font-semibold text-[#173F35] link-underline" data-testid="faq-call-link">
                Call us
              </a>{" "}
              or{" "}
              <a href={site.whatsappUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-[#173F35] link-underline" data-testid="faq-whatsapp-link">
                WhatsApp
              </a>
              .
            </p>
            <p className="mt-4 hidden items-center gap-2 text-sm text-[#687572] lg:flex">
              <Phone className="h-4 w-4 text-[#C88A3D]" aria-hidden="true" /> {site.phone}
              <MessageCircle className="ml-3 h-4 w-4 text-[#C88A3D]" aria-hidden="true" /> WhatsApp
            </p>
          </Reveal>
          <Reveal delay={0.1} className="lg:col-span-8">
            <FAQ items={faqs} />
          </Reveal>
        </div>
      </section>

      <CTASection />
    </>
  );
};

export default Home;
