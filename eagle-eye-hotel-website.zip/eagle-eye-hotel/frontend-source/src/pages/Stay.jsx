import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, BedDouble, ShowerHead, Sofa, Wifi, Info } from "lucide-react";
import { PageHero } from "../components/PageHero";
import { Reveal, Stagger, StaggerItem } from "../components/Reveal";
import { ImageWithFallback } from "../components/ImageWithFallback";
import { CTASection } from "../components/CTASection";
import { site, stayFeatures, rooms, imagery } from "../data/siteData";

const featureIcons = { bed: BedDouble, shower: ShowerHead, sofa: Sofa, wifi: Wifi };

const Stay = () => {
  useEffect(() => {
    document.title = "Stay in Chame | Eagle Eye Hotel — Rooms on the Annapurna Circuit";
  }, []);

  return (
    <>
      <PageHero
        image={imagery.heroStay}
        alt={imagery.heroStayAlt}
        eyebrow="Stay · Eagle Eye Hotel, Chame"
        lines={["A Warm Bed", "After the Long Trail."]}
      >
        <p className="max-w-xl text-base leading-relaxed text-[#F7F5F0]/85 sm:text-lg">
          Simple, warm and welcoming — everything a trekker needs before the next leg
          of the Annapurna Circuit.
        </p>
        <Link to="/contact" className="btn-amber mt-8" data-testid="stay-book-cta">
          Book Your Stay <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </Link>
      </PageHero>

      <section className="py-24 sm:py-32" data-testid="stay-rooms-section">
        <div className="container-ee">
          <Reveal className="max-w-2xl">
            <p className="eyebrow">Rooms</p>
            <h2 className="font-display mt-3 text-4xl leading-[1.08] text-[#17201F] sm:text-5xl">
              Choose Your Room
            </h2>
          </Reveal>

          <Reveal delay={0.05}>
            <div className="mt-8 flex items-start gap-3 rounded-2xl border border-[#C88A3D]/40 bg-[#E9D7B8]/40 p-5 text-sm text-[#40545A]" data-testid="owner-confirm-note">
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#C88A3D]" aria-hidden="true" />
              <p>
                Room details and rates below are editable placeholders awaiting
                confirmation from the hotel. For today's availability and prices, call{" "}
                <a href={site.phoneHref} className="font-semibold text-[#173F35] link-underline">{site.phone}</a>.
              </p>
            </div>
          </Reveal>

          <Stagger className="mt-12 grid gap-6 md:grid-cols-3">
            {rooms.map((r, i) => (
              <StaggerItem key={r.name}>
                <article className="card-ee group h-full overflow-hidden" data-testid={`room-card-${i}`}>
                  <div className="overflow-hidden">
                    <ImageWithFallback
                      src={r.image}
                      alt={r.alt}
                      className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-7">
                    <h3 className="font-display text-2xl text-[#17201F]">{r.name}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-[#687572]">{r.description}</p>
                    <p className="mt-4 text-sm font-semibold text-[#C88A3D]" data-testid={`room-price-${i}`}>
                      {r.price}
                    </p>
                    <Link
                      to="/contact"
                      className="btn-ghost mt-6 w-full !border-[#173F35]/25 text-[#173F35] hover:bg-[#173F35] hover:text-white"
                      data-testid={`room-enquire-${i}`}
                    >
                      Enquire About This Room
                    </Link>
                  </div>
                </article>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      <section className="bg-white py-24 sm:py-32" data-testid="stay-amenities-section">
        <div className="container-ee">
          <Reveal className="max-w-2xl">
            <p className="eyebrow">Comforts</p>
            <h2 className="font-display mt-3 text-4xl leading-[1.08] text-[#17201F] sm:text-5xl">
              What Awaits You Here
            </h2>
          </Reveal>
          <Stagger className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {stayFeatures.map((f) => {
              const Icon = featureIcons[f.icon] || BedDouble;
              return (
                <StaggerItem key={f.title}>
                  <div className="card-ee h-full p-7" data-testid={`amenity-card-${f.icon}`}>
                    <Icon className="h-7 w-7 text-[#C88A3D]" aria-hidden="true" />
                    <h3 className="font-display mt-5 text-xl text-[#17201F]">{f.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-[#687572]">{f.text}</p>
                  </div>
                </StaggerItem>
              );
            })}
          </Stagger>
        </div>
      </section>

      <CTASection />
    </>
  );
};

export default Stay;
