import { useEffect } from "react";
import { Phone, MessageCircle, MapPin, Mail } from "lucide-react";
import { PageHero } from "../components/PageHero";
import { Reveal } from "../components/Reveal";
import { BookingForm } from "../components/BookingForm";
import { LocationSection } from "../components/LocationSection";
import { site, imagery } from "../data/siteData";

const contactCards = [
  {
    icon: Phone,
    title: "Call Us",
    value: site.phone,
    href: site.phoneHref,
    testid: "contact-call-card",
  },
  {
    icon: MessageCircle,
    title: "WhatsApp",
    value: "Chat with the team",
    href: site.whatsappUrl,
    external: true,
    testid: "contact-whatsapp-card",
  },
  {
    icon: MapPin,
    title: "Find Us",
    value: site.address,
    href: site.googleMapsUrl,
    external: true,
    testid: "contact-directions-card",
  },
  {
    icon: Mail,
    title: "Email",
    value: site.email,
    href: null,
    testid: "contact-email-card",
  },
];

const Contact = () => {
  useEffect(() => {
    document.title = "Contact & Location | Eagle Eye Hotel Chame, Manang";
  }, []);

  return (
    <>
      <PageHero
        image={imagery.heroContact}
        alt={imagery.heroContactAlt}
        eyebrow="Contact · Eagle Eye Hotel, Chame"
        lines={["Talk to Us", "Before the Trail."]}
      >
        <p className="max-w-xl text-base leading-relaxed text-[#F7F5F0]/85 sm:text-lg">
          Ask about rooms, food or your arrival in Chame — call, WhatsApp or send an
          enquiry below.
        </p>
      </PageHero>

      <section className="py-20 sm:py-28" data-testid="contact-section">
        <div className="container-ee">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {contactCards.map(({ icon: Icon, title, value, href, external, testid }, i) => (
              <Reveal key={title} delay={i * 0.06}>
                {href ? (
                  <a
                    href={href}
                    {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                    className="card-ee block h-full p-6"
                    data-testid={testid}
                  >
                    <Icon className="h-6 w-6 text-[#C88A3D]" aria-hidden="true" />
                    <h2 className="font-display mt-4 text-lg text-[#17201F]">{title}</h2>
                    <p className="mt-1 text-sm text-[#687572]">{value}</p>
                  </a>
                ) : (
                  <div className="card-ee h-full p-6" data-testid={testid}>
                    <Icon className="h-6 w-6 text-[#C88A3D]" aria-hidden="true" />
                    <h2 className="font-display mt-4 text-lg text-[#17201F]">{title}</h2>
                    <p className="mt-1 text-sm text-[#687572]">{value}</p>
                  </div>
                )}
              </Reveal>
            ))}
          </div>

          <div className="mt-16 grid gap-12 lg:grid-cols-12">
            <Reveal className="lg:col-span-5">
              <p className="eyebrow">Enquiry</p>
              <h2 className="font-display mt-3 text-4xl leading-[1.08] text-[#17201F] sm:text-5xl">
                Send an Enquiry
              </h2>
              <p className="mt-5 text-base leading-relaxed text-[#687572]">
                Tell us your dates and what you need. This form sends an enquiry to the
                hotel team — for the fastest answer during trekking season, call or
                WhatsApp{" "}
                <a href={site.phoneHref} className="font-semibold text-[#173F35] link-underline" data-testid="contact-inline-phone">
                  {site.phone}
                </a>
                .
              </p>
            </Reveal>
            <Reveal delay={0.1} className="lg:col-span-7">
              <BookingForm />
            </Reveal>
          </div>
        </div>
      </section>

      <LocationSection compact />
    </>
  );
};

export default Contact;
