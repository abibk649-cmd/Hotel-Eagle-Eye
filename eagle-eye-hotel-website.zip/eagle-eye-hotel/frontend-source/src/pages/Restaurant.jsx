import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Info, Clock } from "lucide-react";
import { PageHero } from "../components/PageHero";
import { Reveal, Stagger, StaggerItem } from "../components/Reveal";
import { ImageWithFallback } from "../components/ImageWithFallback";
import { CTASection } from "../components/CTASection";
import { site, mealMoments, imagery } from "../data/siteData";

const Restaurant = () => {
  useEffect(() => {
    document.title = "Restaurant in Chame | Eagle Eye Hotel — Food on the Annapurna Circuit";
  }, []);

  return (
    <>
      <PageHero
        image={imagery.heroRestaurant}
        alt={imagery.heroRestaurantAlt}
        eyebrow="Restaurant · Eagle Eye Hotel, Chame"
        lines={["Good Food for", "the Trail Ahead."]}
      >
        <p className="max-w-xl text-base leading-relaxed text-[#F7F5F0]/85 sm:text-lg">
          Start your day with breakfast, settle in for a warm meal after the trail, or
          enjoy a coffee and something freshly baked.
        </p>
        <a href={site.phoneHref} className="btn-amber mt-8" data-testid="restaurant-call-cta">
          Call the Restaurant <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </a>
      </PageHero>

      <section className="py-24 sm:py-32" data-testid="menu-section">
        <div className="container-ee">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <Reveal className="max-w-2xl">
              <p className="eyebrow">Eat &amp; Drink</p>
              <h2 className="font-display mt-3 text-4xl leading-[1.08] text-[#17201F] sm:text-5xl">
                From Morning Coffee to Trail Dinners
              </h2>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="flex items-center gap-2 text-sm text-[#687572]" data-testid="restaurant-hours">
                <Clock className="h-4 w-4 text-[#C88A3D]" aria-hidden="true" />
                Opening hours: {site.openingHours}
              </p>
            </Reveal>
          </div>

          <Reveal delay={0.05}>
            <div className="mt-8 flex items-start gap-3 rounded-2xl border border-[#C88A3D]/40 bg-[#E9D7B8]/40 p-5 text-sm text-[#40545A]" data-testid="menu-confirm-note">
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#C88A3D]" aria-hidden="true" />
              <p>
                Specific dishes will be listed here once confirmed by the restaurant —
                nothing on this page is invented. Ask the team what's cooking today.
              </p>
            </div>
          </Reveal>

          <Stagger className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {mealMoments.map((m, i) => (
              <StaggerItem key={m.title} className={i === 0 ? "sm:col-span-2 lg:col-span-1" : ""}>
                <article className="card-ee group h-full overflow-hidden" data-testid={`menu-card-${m.title.toLowerCase().replace(/\s/g, "-")}`}>
                  <div className="overflow-hidden">
                    <ImageWithFallback
                      src={m.image}
                      alt={m.alt}
                      className="aspect-[16/10] w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-7">
                    <h3 className="font-display text-2xl text-[#17201F]">{m.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-[#687572]">{m.text}</p>
                  </div>
                </article>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      <CTASection />
    </>
  );
};

export default Restaurant;
