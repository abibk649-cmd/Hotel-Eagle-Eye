import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { PageHero } from "../components/PageHero";
import { Reveal } from "../components/Reveal";
import { ImageWithFallback } from "../components/ImageWithFallback";
import { Lightbox } from "../components/Lightbox";
import { CTASection } from "../components/CTASection";
import { galleryCategories, galleryImages, imagery } from "../data/siteData";

const Gallery = () => {
  const [filter, setFilter] = useState("All");
  const [lightboxIndex, setLightboxIndex] = useState(null);

  useEffect(() => {
    document.title = "Gallery | Eagle Eye Hotel Chame, Manang";
  }, []);

  const filtered = useMemo(
    () => (filter === "All" ? galleryImages : galleryImages.filter((g) => g.category === filter)),
    [filter]
  );

  return (
    <>
      <PageHero
        image={imagery.heroGallery}
        alt={imagery.heroGalleryAlt}
        eyebrow="Gallery · Eagle Eye Hotel, Chame"
        lines={["The Mountain,", "the Table, the Rooms."]}
      >
        <p className="max-w-xl text-base leading-relaxed text-[#F7F5F0]/85 sm:text-lg">
          Demo photography from licensed stock — the hotel's own photos will replace
          these once supplied by the owner.
        </p>
      </PageHero>

      <section className="py-20 sm:py-28" data-testid="gallery-section">
        <div className="container-ee">
          <Reveal>
            <div className="flex flex-wrap gap-2" role="group" aria-label="Filter gallery by category">
              {galleryCategories.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => { setFilter(c); setLightboxIndex(null); }}
                  aria-pressed={filter === c}
                  data-testid={`gallery-filter-${c.toLowerCase()}`}
                  className={`min-h-[44px] rounded-full border px-5 text-sm font-semibold transition-colors duration-200 ${
                    filter === c
                      ? "border-[#173F35] bg-[#173F35] text-white"
                      : "border-[#173F35]/20 bg-white text-[#173F35] hover:border-[#173F35]"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </Reveal>

          <div className="mt-10 columns-2 gap-4 lg:columns-3" data-testid="gallery-grid">
            {filtered.map((img, i) => (
              <motion.button
                key={img.src}
                type="button"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.4, delay: Math.min(i * 0.04, 0.4) }}
                onClick={() => setLightboxIndex(i)}
                className="group mb-4 block w-full overflow-hidden rounded-2xl focus-visible:outline-2"
                aria-label={`Open image: ${img.alt}`}
                data-testid={`gallery-item-${i}`}
              >
                <ImageWithFallback
                  src={img.src}
                  alt={img.alt}
                  className={`w-full object-cover transition-transform duration-700 group-hover:scale-105 ${
                    img.tall ? "aspect-[3/4]" : "aspect-square"
                  }`}
                />
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      <Lightbox
        images={filtered}
        index={lightboxIndex}
        onClose={() => setLightboxIndex(null)}
        onNavigate={setLightboxIndex}
      />

      <CTASection />
    </>
  );
};

export default Gallery;
