// ============================================================
// EAGLE EYE HOTEL — EDITABLE BUSINESS DATA
// Every value the owner may need to change lives in this file.
// Values marked "[OWNER TO CONFIRM]" are placeholders awaiting
// confirmation from the business. Do not present them as fact.
// ============================================================

export const site = {
  businessName: "Eagle Eye Hotel",
  tagline: "Hotel & Restaurant",
  positioning: "A warm mountain stay for trekkers traveling through Chame.",

  address: "H62V+84Q, Chame 33500, Nepal",
  area: "Chame · Manang",
  category: "Hotel + Restaurant",

  phone: "+977 984 684 9935",
  phoneHref: "tel:+9779846849935",
  whatsappNumber: "9779846849935",
  whatsappUrl:
    "https://wa.me/9779846849935?text=" +
    encodeURIComponent("Hello Eagle Eye Hotel, I'd like to ask about a stay in Chame."),
  email: "[OWNER TO CONFIRM]",

  // Editable map / review links (replace with the official business URLs)
  googleMapsUrl:
    "https://www.google.com/maps/search/?api=1&query=" +
    encodeURIComponent("Eagle Eye Hotel, H62V+84Q, Chame 33500, Nepal"),
  mapEmbedUrl:
    "https://www.google.com/maps?q=" +
    encodeURIComponent("Eagle Eye Hotel, Chame 33500, Nepal") +
    "&output=embed",
  googleReviewUrl:
    "https://www.google.com/maps/search/?api=1&query=" +
    encodeURIComponent("Eagle Eye Hotel Chame reviews"),

  websiteUrl: "[OWNER TO CONFIRM]",
  bookingUrl: "[OWNER TO CONFIRM]", // falls back to /contact enquiry form
  // Relative path: works when the frontend build and API are served from the
  // same domain with /api proxied to the backend (see deployment README).
  formEndpoint: "/api/enquiries",

  // Publicly visible Google snapshot — EDITABLE, counts change over time
  rating: "4.8",
  reviewCount: "800+",

  openingHours: "[OWNER TO CONFIRM]",

  socialLinks: {
    facebook: "[OWNER TO CONFIRM]",
    instagram: "[OWNER TO CONFIRM]",
    tripadvisor: "[OWNER TO CONFIRM]",
  },
};

export const navLinks = [
  { label: "Stay", to: "/stay" },
  { label: "Restaurant", to: "/restaurant" },
  { label: "Gallery", to: "/gallery" },
  { label: "About", to: "/#about" },
  { label: "Contact", to: "/contact" },
];

// ---- Stay features (all editable) ----
export const stayFeatures = [
  {
    title: "Comfortable Rooms",
    text: "A warm bed and a quiet night after a long day on the trail. [OWNER TO CONFIRM — room details]",
    icon: "bed",
  },
  {
    title: "Hot Showers",
    text: "Wash off the trail dust and warm up. [OWNER TO CONFIRM — availability]",
    icon: "shower",
  },
  {
    title: "Cozy Common Space",
    text: "A place to sit, eat, plan the next leg and meet other trekkers. [OWNER TO CONFIRM]",
    icon: "sofa",
  },
  {
    title: "Wi-Fi",
    text: "Check in with home and plan the route ahead. [OWNER TO CONFIRM — speed/availability]",
    icon: "wifi",
  },
];

// ---- Rooms (editable placeholders — no invented specs or prices) ----
export const rooms = [
  {
    name: "Room Type 1",
    description: "[OWNER TO CONFIRM — bed type, occupancy, view, bathroom]",
    price: "[OWNER TO CONFIRM]",
    image:
      "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=70",
    alt: "Comfortable hotel room, placeholder image for Eagle Eye Hotel Chame",
  },
  {
    name: "Room Type 2",
    description: "[OWNER TO CONFIRM — bed type, occupancy, view, bathroom]",
    price: "[OWNER TO CONFIRM]",
    image:
      "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=70",
    alt: "Warm guest room, placeholder image for Eagle Eye Hotel Chame",
  },
  {
    name: "Room Type 3",
    description: "[OWNER TO CONFIRM — bed type, occupancy, view, bathroom]",
    price: "[OWNER TO CONFIRM]",
    image:
      "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=70",
    alt: "Simple mountain accommodation room, placeholder image",
  },
];

// ---- Restaurant (meal moments — dishes only after owner confirmation) ----
export const mealMoments = [
  {
    title: "Breakfast",
    text: "Start the trekking day well fed. [OWNER TO CONFIRM — breakfast menu]",
    image:
      "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?auto=format&fit=crop&w=1200&q=70",
    alt: "Breakfast table with coffee and eggs, placeholder food image",
  },
  {
    title: "Local Meals",
    text: "Warm, filling local dishes after the trail. [OWNER TO CONFIRM — e.g. dal bhat]",
    image:
      "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=70",
    alt: "Freshly served meal, placeholder food image for Eagle Eye restaurant",
  },
  {
    title: "Coffee",
    text: "A good cup of coffee with a mountain backdrop. [OWNER TO CONFIRM]",
    image:
      "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1200&q=70",
    alt: "Freshly brewed coffee, placeholder image",
  },
  {
    title: "Bakery",
    text: "Something freshly baked with your tea. [OWNER TO CONFIRM — bakery items]",
    image:
      "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=1200&q=70",
    alt: "Freshly baked bread, placeholder bakery image",
  },
  {
    title: "Dinner",
    text: "Settle in for a warm evening meal. [OWNER TO CONFIRM — dinner menu]",
    image:
      "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1200&q=70",
    alt: "Restaurant table set for dinner, placeholder dining image",
  },
];

// ---- Why Eagle Eye ----
export const whyFeatures = [
  {
    n: "01",
    title: "Warm Hospitality",
    text: "A friendly atmosphere that makes a mountain stay feel personal.",
  },
  {
    n: "02",
    title: "Comfort After the Trail",
    text: "A welcoming place to relax after a long day outdoors.",
  },
  {
    n: "03",
    title: "Food & Coffee",
    text: "Enjoy a selection of meals, drinks and bakery offerings.",
  },
  {
    n: "04",
    title: "Chame Location",
    text: "Stay in one of the important stops along the Annapurna Circuit.",
  },
];

// ---- Annapurna route (no distances/times — unverified) ----
export const routeStops = ["Dharapani", "Chame", "Pisang", "Manang"];

// ---- Gallery (licensed stock placeholders, categorized) ----
export const galleryCategories = [
  "All",
  "Hotel",
  "Rooms",
  "Restaurant",
  "Food",
  "Mountains",
  "Chame",
];

export const galleryImages = [
  { src: "https://images.unsplash.com/photo-1517840901100-8179e982acb7?auto=format&fit=crop&w=1200&q=70", category: "Hotel", alt: "Hotel exterior at dusk, placeholder image for Eagle Eye Hotel in Chame Manang", tall: false },
  { src: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1200&q=70", category: "Chame", alt: "Prayer flags and mountains in Nepal, placeholder image of the Chame region", tall: true },
  { src: "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=70", category: "Rooms", alt: "Comfortable hotel room interior, placeholder room image", tall: true },
  { src: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=70", category: "Food", alt: "Food served at Eagle Eye Hotel, placeholder dish image", tall: false },
  { src: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=1200&q=70", category: "Mountains", alt: "Mountain view from Chame Manang, placeholder Himalayan image", tall: false },
  { src: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=1200&q=70", category: "Restaurant", alt: "Hotel dining area in Chame, placeholder restaurant image", tall: true },
  { src: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=70", category: "Rooms", alt: "Cozy guest room, placeholder room image", tall: false },
  { src: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=70", category: "Mountains", alt: "Snow covered Himalayan peaks, placeholder mountain image", tall: true },
  { src: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=1200&q=70", category: "Food", alt: "Fresh bakery items, placeholder bakery image", tall: false },
  { src: "https://images.unsplash.com/photo-1551632811-561732d1e306?auto=format&fit=crop&w=1200&q=70", category: "Chame", alt: "Trekkers on a Himalayan trail near Chame, placeholder trekking image", tall: true },
  { src: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1200&q=70", category: "Restaurant", alt: "Warm restaurant interior, placeholder dining image", tall: false },
  { src: "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1200&q=70", category: "Mountains", alt: "Stars over snowy mountains at night, placeholder image", tall: true },
  { src: "https://images.unsplash.com/photo-1521017432531-fbd92d768814?auto=format&fit=crop&w=1200&q=70", category: "Restaurant", alt: "Coffeehouse seating area, placeholder cafe image", tall: false },
  { src: "https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?auto=format&fit=crop&w=1200&q=70", category: "Food", alt: "Colorful fresh dish, placeholder food image", tall: false },
  { src: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1200&q=70", category: "Chame", alt: "Forest trail in the Manang region, placeholder nature image", tall: true },
  { src: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=70", category: "Rooms", alt: "Bright simple room, placeholder room image", tall: false },
  { src: "https://images.unsplash.com/photo-1465056836041-7f43ac27dcb5?auto=format&fit=crop&w=1200&q=70", category: "Mountains", alt: "Hiker looking at a mountain valley, placeholder image", tall: false },
  { src: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1200&q=70", category: "Food", alt: "Coffee served at Eagle Eye Hotel, placeholder image", tall: true },
];

// ---- FAQ (all answers editable) ----
export const faqs = [
  {
    q: "Is Eagle Eye Hotel in Chame?",
    a: "Yes. Eagle Eye Hotel is located in Chame, Manang (H62V+84Q, Chame 33500, Nepal) — one of the key stops along the Annapurna Circuit.",
  },
  {
    q: "Does Eagle Eye Hotel have a restaurant?",
    a: "Yes, Eagle Eye is a hotel and restaurant serving travelers and trekkers in Chame. [OWNER TO CONFIRM — current menu and serving times]",
  },
  {
    q: "Is Eagle Eye suitable for Annapurna Circuit trekkers?",
    a: "Yes. Chame is a popular overnight stop on the Annapurna Circuit, and Eagle Eye welcomes trekkers passing through in either direction.",
  },
  {
    q: "What food is available?",
    a: "Breakfast, local meals, coffee, bakery items and dinner. [OWNER TO CONFIRM — specific dishes will be listed here once confirmed by the restaurant]",
  },
  {
    q: "Can I contact the hotel directly?",
    a: "Yes — call or WhatsApp us on +977 984 684 9935, or send an enquiry through the contact form on this website.",
  },
  {
    q: "Can I request a room before arriving?",
    a: "You can send an enquiry with your dates through the contact form or WhatsApp, and the team will confirm availability. [OWNER TO CONFIRM — booking policy]",
  },
];

// ---- Hero / section imagery (licensed stock placeholders) ----
export const imagery = {
  heroHome:
    "https://images.unsplash.com/photo-1483728642387-6c3bdd6c93e5?auto=format&fit=crop&w=2000&q=75",
  heroHomeAlt: "Himalayan peaks above the clouds near the Annapurna Circuit, placeholder image",
  intro:
    "https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1400&q=70",
  introAlt: "Prayer flags in a Himalayan village, placeholder hospitality image",
  route:
    "https://images.unsplash.com/photo-1454496522488-7a8e488e8606?auto=format&fit=crop&w=2000&q=70",
  routeAlt: "Misty Himalayan ridgelines, placeholder Annapurna region image",
  heroStay:
    "https://images.unsplash.com/photo-1517840901100-8179e982acb7?auto=format&fit=crop&w=2000&q=70",
  heroStayAlt: "Welcoming hotel exterior in the evening, placeholder image",
  heroRestaurant:
    "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=2000&q=70",
  heroRestaurantAlt: "Warm restaurant dining room, placeholder image",
  heroGallery:
    "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=2000&q=70",
  heroGalleryAlt: "Snow covered mountain range, placeholder image",
  heroContact:
    "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=2000&q=70",
  heroContactAlt: "Sunrise over foggy hills, placeholder image",
};

// ---- Reviews ----
// No fabricated testimonials. Add ONLY genuine, owner-approved reviews here.
// Shape per review:
// {
//   text: "Exact review quote as approved by the owner",
//   name: "Reviewer name (only if legally/publicly appropriate)",
//   source: "Google" | "TripAdvisor" | "Booking.com" | ...,
//   rating: 1-5,
//   date: "Month YYYY" (optional),
// }
// Cards appear automatically on the home page as soon as entries exist.
export const verifiedReviews = [];
