import { Link } from "react-router-dom";
import { Phone, MessageCircle, MapPin } from "lucide-react";
import { Reveal } from "./Reveal";
import { site } from "../data/siteData";

export const CTASection = () => (
  <section className="grain relative overflow-hidden bg-[#173F35] py-24 text-white sm:py-32" data-testid="final-cta-section">
    <div className="container-ee relative text-center">
      <Reveal>
        <p className="eyebrow">Chame · Manang · Annapurna Circuit</p>
        <h2 className="font-display mx-auto mt-4 max-w-2xl text-4xl leading-[1.08] sm:text-5xl lg:text-6xl">
          Planning Your Stop in Chame?
        </h2>
        <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-[#F7F5F0]/75 sm:text-lg">
          Make Eagle Eye Hotel part of your Annapurna journey. Get in touch to ask about
          your stay, food or arrival.
        </p>
      </Reveal>
      <Reveal delay={0.12}>
        <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <a href={site.phoneHref} className="btn-amber w-full sm:w-auto" data-testid="cta-call-button">
            <Phone className="h-4 w-4" aria-hidden="true" /> Call Eagle Eye
          </a>
          <a
            href={site.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ghost w-full text-white hover:bg-white/10 sm:w-auto"
            data-testid="cta-whatsapp-button"
          >
            <MessageCircle className="h-4 w-4" aria-hidden="true" /> WhatsApp Us
          </a>
          <a
            href={site.googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ghost w-full text-white hover:bg-white/10 sm:w-auto"
            data-testid="cta-directions-button"
          >
            <MapPin className="h-4 w-4" aria-hidden="true" /> Get Directions
          </a>
        </div>
        <p className="mt-8 text-sm text-[#F7F5F0]/60">
          Prefer to write?{" "}
          <Link to="/contact" className="font-semibold text-[#C88A3D] link-underline" data-testid="cta-enquiry-link">
            Send us an enquiry
          </Link>
        </p>
      </Reveal>
    </div>
  </section>
);
