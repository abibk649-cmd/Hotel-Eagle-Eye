import { useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { faqs } from "../data/siteData";

export const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(0);
  const reduce = useReducedMotion();

  return (
    <div className="divide-y divide-[#173F35]/10 border-y border-[#173F35]/10" data-testid="faq-accordion">
      {faqs.map((f, i) => {
        const open = openIndex === i;
        return (
          <div key={f.q}>
            <h3>
              <button
                type="button"
                onClick={() => setOpenIndex(open ? -1 : i)}
                aria-expanded={open}
                aria-controls={`faq-panel-${i}`}
                data-testid={`faq-question-${i}`}
                className="flex w-full items-center justify-between gap-4 py-5 text-left"
              >
                <span className="font-display text-lg text-[#17201F] sm:text-xl">{f.q}</span>
                <ChevronDown
                  className={`h-5 w-5 shrink-0 text-[#C88A3D] transition-transform duration-300 ${
                    open ? "rotate-180" : ""
                  }`}
                  aria-hidden="true"
                />
              </button>
            </h3>
            <AnimatePresence initial={false}>
              {open && (
                <motion.div
                  id={`faq-panel-${i}`}
                  initial={reduce ? { opacity: 0 } : { height: 0, opacity: 0 }}
                  animate={reduce ? { opacity: 1 } : { height: "auto", opacity: 1 }}
                  exit={reduce ? { opacity: 0 } : { height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                  data-testid={`faq-answer-${i}`}
                >
                  <p className="max-w-3xl pb-6 text-[15px] leading-relaxed text-[#687572]">{f.a}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
};
