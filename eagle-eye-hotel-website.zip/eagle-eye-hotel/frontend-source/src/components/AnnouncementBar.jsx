import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { site } from "../data/siteData";

export const AnnouncementBar = () => (
  <div
    className="bg-[#C88A3D] text-[#17201F]"
    data-testid="announcement-bar"
  >
    <div className="container-ee flex min-h-[40px] flex-wrap items-center justify-center gap-x-4 gap-y-1 py-1.5 text-center text-[13px] font-medium">
      <span>A warm mountain stay in Chame, Manang · Annapurna Circuit</span>
      <Link
        to="/contact"
        data-testid="announcement-book-cta"
        className="link-underline inline-flex items-center gap-1 font-semibold"
      >
        Book Your Stay <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
      </Link>
      <span className="sr-only">{site.positioning}</span>
    </div>
  </div>
);
