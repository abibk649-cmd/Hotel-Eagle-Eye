import { useState } from "react";
import { Mountain } from "lucide-react";

export const ImageWithFallback = ({ src, alt, className = "", eager = false }) => {
  const [failed, setFailed] = useState(false);
  if (failed) {
    return (
      <div
        className={`flex items-center justify-center bg-[#40545A] text-[#F7F5F0] ${className}`}
        role="img"
        aria-label={alt}
        data-testid="image-fallback"
      >
        <Mountain className="h-10 w-10 opacity-50" aria-hidden="true" />
      </div>
    );
  }
  return (
    <img
      src={src}
      alt={alt}
      loading={eager ? "eager" : "lazy"}
      decoding="async"
      onError={() => setFailed(true)}
      className={className}
    />
  );
};
