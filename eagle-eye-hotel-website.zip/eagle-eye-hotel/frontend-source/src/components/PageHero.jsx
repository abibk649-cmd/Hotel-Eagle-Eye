import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { MaskedLines } from "../components/Reveal";
import { ImageWithFallback } from "../components/ImageWithFallback";

export const PageHero = ({ image, alt, eyebrow, lines, children, fullHeight = false }) => {
  const ref = useRef(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", reduce ? "0%" : "18%"]);

  return (
    <section
      ref={ref}
      className={`grain relative flex items-end overflow-hidden bg-[#0F3028] ${
        fullHeight ? "min-h-[92vh]" : "min-h-[58vh] sm:min-h-[64vh]"
      }`}
      data-testid="page-hero"
    >
      <motion.div style={{ y }} className="absolute inset-0 scale-110">
        <ImageWithFallback
          src={image}
          alt={alt}
          eager
          className="h-full w-full object-cover"
        />
      </motion.div>
      <div className="absolute inset-0 bg-gradient-to-t from-[#0F3028] via-[#0F3028]/45 to-[#0F3028]/20" aria-hidden="true" />

      <div className="container-ee relative pb-16 pt-40 sm:pb-24">
        {eyebrow && (
          <motion.p
            initial={reduce ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="eyebrow"
          >
            {eyebrow}
          </motion.p>
        )}
        <h1 className="font-display mt-4 max-w-4xl text-[42px] leading-[1.04] text-white sm:text-6xl lg:text-7xl" data-testid="page-hero-heading">
          <MaskedLines lines={lines} />
        </h1>
        {children && (
          <motion.div
            initial={reduce ? false : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.65, duration: 0.7 }}
            className="mt-8"
          >
            {children}
          </motion.div>
        )}
      </div>
    </section>
  );
};
