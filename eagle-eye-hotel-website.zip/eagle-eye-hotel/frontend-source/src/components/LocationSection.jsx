import { MapPin, Phone, MessageCircle, Clock } from "lucide-react";
import { Reveal } from "./Reveal";
import { site } from "../data/siteData";

export const LocationSection = ({ compact = false }) => (
  <section className="bg-white py-20 sm:py-28" data-testid="location-section">
    <div className="container-ee">
      <Reveal className="mb-12 max-w-2xl">
        <p className="eyebrow">Location</p>
        <h2 className="font-display mt-3 text-4xl leading-[1.1] text-[#17201F] sm:text-5xl">
          Find Eagle Eye in Chame
        </h2>
      </Reveal>

      <div className="grid gap-8 lg:grid-cols-5">
        <Reveal className="lg:col-span-2">
          <div className="card-ee h-full p-7">
            <dl className="space-y-6">
              <div className="flex gap-4">
                <MapPin className="mt-1 h-5 w-5 shrink-0 text-[#C88A3D]" aria-hidden="true" />
                <div>
                  <dt className="text-xs font-semibold uppercase tracking-[0.18em] text-[#687572]">Address</dt>
                  <dd className="mt-1 text-[15px] text-[#17201F]" data-testid="location-address">{site.address}</dd>
                </div>
              </div>
              <div className="flex gap-4">
                <Phone className="mt-1 h-5 w-5 shrink-0 text-[#C88A3D]" aria-hidden="true" />
                <div>
                  <dt className="text-xs font-semibold uppercase tracking-[0.18em] text-[#687572]">Phone</dt>
                  <dd className="mt-1">
                    <a href={site.phoneHref} className="text-[15px] font-medium text-[#173F35] link-underline" data-testid="location-phone-link">
                      {site.phone}
                    </a>
                  </dd>
                </div>
              </div>
              <div className="flex gap-4">
                <Clock className="mt-1 h-5 w-5 shrink-0 text-[#C88A3D]" aria-hidden="true" />
                <div>
                  <dt className="text-xs font-semibold uppercase tracking-[0.18em] text-[#687572]">Opening Hours</dt>
                  <dd className="mt-1 text-[15px] text-[#17201F]" data-testid="location-hours">{site.openingHours}</dd>
                </div>
              </div>
            </dl>
            <div className="mt-8 flex flex-col gap-3">
              <a href={site.googleMapsUrl} target="_blank" rel="noopener noreferrer" className="btn-primary" data-testid="location-directions-button">
                <MapPin className="h-4 w-4" aria-hidden="true" /> Get Directions
              </a>
              <div className="grid grid-cols-2 gap-3">
                <a href={site.phoneHref} className="btn-ghost !px-4 text-[#173F35]" data-testid="location-call-button">
                  <Phone className="h-4 w-4" aria-hidden="true" /> Call
                </a>
                <a href={site.whatsappUrl} target="_blank" rel="noopener noreferrer" className="btn-ghost !px-4 text-[#173F35]" data-testid="location-whatsapp-button">
                  <MessageCircle className="h-4 w-4" aria-hidden="true" /> WhatsApp
                </a>
              </div>
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.1} className="lg:col-span-3">
          <div className={`overflow-hidden rounded-2xl border border-[#173F35]/10 ${compact ? "h-[340px]" : "h-[340px] lg:h-full lg:min-h-[420px]"}`}>
            <iframe
              title="Map showing Eagle Eye Hotel in Chame, Manang, Nepal"
              src={site.mapEmbedUrl}
              className="h-full w-full"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
              data-testid="location-map-embed"
            />
          </div>
        </Reveal>
      </div>
    </div>
  </section>
);
