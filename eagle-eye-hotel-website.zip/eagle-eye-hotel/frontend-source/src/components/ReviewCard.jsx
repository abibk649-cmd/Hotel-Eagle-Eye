import { Star, Quote } from "lucide-react";

export const ReviewCard = ({ review, index }) => (
  <figure className="card-ee flex h-full flex-col p-7" data-testid={`review-card-${index}`}>
    <Quote className="h-6 w-6 text-[#C88A3D]" aria-hidden="true" />
    <blockquote className="mt-4 flex-1 text-[15px] leading-relaxed text-[#17201F]">
      {review.text}
    </blockquote>
    <figcaption className="mt-6 border-t border-[#173F35]/10 pt-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-semibold text-[#17201F]" data-testid={`review-name-${index}`}>
            {review.name}
          </p>
          <p className="mt-0.5 text-xs text-[#687572]" data-testid={`review-source-${index}`}>
            {review.source}
            {review.date ? ` · ${review.date}` : ""}
          </p>
        </div>
        <div className="flex shrink-0 gap-0.5" aria-label={`${review.rating} out of 5 stars`}>
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`h-3.5 w-3.5 ${
                i < review.rating ? "fill-[#C88A3D] text-[#C88A3D]" : "text-[#173F35]/20"
              }`}
              aria-hidden="true"
            />
          ))}
        </div>
      </div>
    </figcaption>
  </figure>
);
