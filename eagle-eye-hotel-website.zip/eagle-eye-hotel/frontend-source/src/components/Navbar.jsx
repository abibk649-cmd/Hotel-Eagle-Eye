import { useEffect, useState } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { Logo } from "./Logo";
import { navLinks } from "../data/siteData";

export const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const reduce = useReducedMotion();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [location.pathname, location.hash]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const goTo = (link) => (e) => {
    if (link.to.startsWith("/#")) {
      e.preventDefault();
      const id = link.to.slice(2);
      if (location.pathname !== "/") {
        navigate("/");
        setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: reduce ? "auto" : "smooth" }), 350);
      } else {
        document.getElementById(id)?.scrollIntoView({ behavior: reduce ? "auto" : "smooth" });
      }
      setOpen(false);
    }
  };

  const linkCls = ({ isActive }) =>
    `relative text-sm font-medium tracking-wide transition-colors duration-200 link-underline ${
      isActive ? "text-[#C88A3D]" : "text-[#F7F5F0]/85 hover:text-white"
    }`;

  return (
    <header
      className={`sticky top-0 z-40 bg-[#173F35] transition-shadow duration-300 ${
        scrolled ? "shadow-[0_6px_24px_-10px_rgba(15,48,40,0.6)]" : ""
      }`}
      data-testid="main-navbar"
    >
      <nav
        className="container-ee flex h-[72px] items-center justify-between"
        aria-label="Main navigation"
      >
        <Link to="/" aria-label="Eagle Eye Hotel — home" data-testid="nav-logo-link">
          <Logo light />
        </Link>

        <div className="hidden items-center gap-8 lg:flex">
          {navLinks.map((l) =>
            l.to.startsWith("/#") ? (
              <a
                key={l.label}
                href={l.to}
                onClick={goTo(l)}
                data-testid={`nav-link-${l.label.toLowerCase()}`}
                className="text-sm font-medium tracking-wide text-[#F7F5F0]/85 transition-colors duration-200 link-underline hover:text-white"
              >
                {l.label}
              </a>
            ) : (
              <NavLink
                key={l.label}
                to={l.to}
                className={linkCls}
                data-testid={`nav-link-${l.label.toLowerCase()}`}
              >
                {l.label}
              </NavLink>
            )
          )}
          <Link to="/contact" className="btn-amber !min-h-[44px] !px-6 !py-2" data-testid="nav-book-cta">
            Book Your Stay
          </Link>
        </div>

        <button
          type="button"
          className="flex h-12 w-12 items-center justify-center rounded-full text-white lg:hidden"
          onClick={() => setOpen(!open)}
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? "Close menu" : "Open menu"}
          data-testid="mobile-menu-toggle"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            initial={reduce ? { opacity: 0 } : { opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: reduce ? 0 : -12 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-x-0 top-[72px] bottom-0 z-40 overflow-y-auto bg-[#0F3028] lg:hidden"
            data-testid="mobile-menu"
          >
            <div className="container-ee flex flex-col gap-2 py-10">
              {navLinks.map((l, i) => (
                <motion.div
                  key={l.label}
                  initial={reduce ? false : { opacity: 0, x: -18 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.06 * i, duration: 0.35 }}
                >
                  {l.to.startsWith("/#") ? (
                    <a
                      href={l.to}
                      onClick={goTo(l)}
                      data-testid={`mobile-nav-link-${l.label.toLowerCase()}`}
                      className="font-display block py-3 text-4xl text-[#F7F5F0]"
                    >
                      {l.label}
                    </a>
                  ) : (
                    <Link
                      to={l.to}
                      data-testid={`mobile-nav-link-${l.label.toLowerCase()}`}
                      className="font-display block py-3 text-4xl text-[#F7F5F0]"
                    >
                      {l.label}
                    </Link>
                  )}
                </motion.div>
              ))}
              <motion.div
                initial={reduce ? false : { opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.36, duration: 0.35 }}
                className="pt-6"
              >
                <Link to="/contact" className="btn-amber w-full" data-testid="mobile-nav-book-cta">
                  Book Your Stay
                </Link>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
