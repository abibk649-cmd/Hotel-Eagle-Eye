import { Link } from "react-router-dom";
import { Phone, MessageCircle, MapPin } from "lucide-react";
import { Logo } from "./Logo";
import { site, navLinks } from "../data/siteData";

const socials = [
  { label: "Facebook", key: "facebook" },
  { label: "Instagram", key: "instagram" },
  { label: "TripAdvisor", key: "tripadvisor" },
];

export const Footer = () => (
  <footer className="bg-[#0F3028] pb-24 pt-16 text-[#F7F5F0] md:pb-16" data-testid="site-footer">
    <div className="container-ee">
      <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <Logo light />
          <p className="mt-5 max-w-xs text-sm leading-relaxed text-[#F7F5F0]/70">
            A warm mountain hotel and restaurant in Chame, Manang — serving trekkers and
            travelers along the Annapurna Circuit.
          </p>
        </div>

        <nav aria-label="Footer navigation">
          <h3 className="eyebrow mb-4">Explore</h3>
          <ul className="space-y-2.5 text-sm">
            {navLinks.map((l) => (
              <li key={l.label}>
                <Link
                  to={l.to.startsWith("/#") ? "/" : l.to}
                  className="text-[#F7F5F0]/80 transition-colors hover:text-[#C88A3D] link-underline"
                  data-testid={`footer-link-${l.label.toLowerCase()}`}
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h3 className="eyebrow mb-4">Find Us</h3>
          <address className="space-y-3 text-sm not-italic text-[#F7F5F0]/80">
            <p>{site.address}</p>
            <p>
              <a
                href={site.phoneHref}
                className="inline-flex items-center gap-2 transition-colors hover:text-[#C88A3D]"
                data-testid="footer-phone-link"
              >
                <Phone className="h-4 w-4" aria-hidden="true" /> {site.phone}
              </a>
            </p>
            <p>
              <a
                href={site.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 transition-colors hover:text-[#C88A3D]"
                data-testid="footer-whatsapp-link"
              >
                <MessageCircle className="h-4 w-4" aria-hidden="true" /> WhatsApp
              </a>
            </p>
            <p>
              <a
                href={site.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 transition-colors hover:text-[#C88A3D]"
                data-testid="footer-maps-link"
              >
                <MapPin className="h-4 w-4" aria-hidden="true" /> Google Maps
              </a>
            </p>
          </address>
        </div>

        <div>
          <h3 className="eyebrow mb-4">Follow</h3>
          <ul className="space-y-2.5 text-sm">
            {socials.map((s) => (
              <li key={s.key} className="text-[#F7F5F0]/60" data-testid={`footer-social-${s.key}`}>
                {s.label}{" "}
                <span className="text-xs text-[#F7F5F0]/40">— [OWNER TO CONFIRM]</span>
              </li>
            ))}
          </ul>
          <p className="mt-6 text-xs leading-relaxed text-[#F7F5F0]/50">
            Opening hours: {site.openingHours}
          </p>
        </div>
      </div>

      <div className="mt-14 border-t border-white/10 pt-6 text-center text-xs text-[#F7F5F0]/50">
        © Eagle Eye Hotel. All rights reserved.
      </div>
    </div>
  </footer>
);
