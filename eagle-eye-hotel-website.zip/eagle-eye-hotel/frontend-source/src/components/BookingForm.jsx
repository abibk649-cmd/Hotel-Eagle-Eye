import { useState } from "react";
import { Loader2, CheckCircle2, AlertCircle } from "lucide-react";
import { site, rooms } from "../data/siteData";

const inputCls =
  "w-full rounded-xl border border-[#173F35]/15 bg-white px-4 py-3 text-[15px] text-[#17201F] placeholder:text-[#687572]/60 transition-colors focus:border-[#C88A3D] focus:outline-none min-h-[48px]";

export const BookingForm = () => {
  const [form, setForm] = useState({
    name: "",
    arrivalDate: "",
    departureDate: "",
    guests: "",
    roomPreference: "",
    message: "",
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle"); // idle | loading | success | error

  const set = (k) => (e) => {
    setForm({ ...form, [k]: e.target.value });
    setErrors({ ...errors, [k]: undefined });
  };

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Please tell us your name.";
    if (form.arrivalDate && form.departureDate && form.departureDate < form.arrivalDate)
      e.departureDate = "Departure must be after arrival.";
    return e;
  };

  const submit = async (ev) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return;
    setStatus("loading");
    try {
      const res = await fetch(site.formEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("Request failed");
      setStatus("success");
    } catch {
      setStatus("error");
    }
  };

  if (status === "success") {
    return (
      <div
        className="card-ee flex flex-col items-center gap-4 p-10 text-center"
        role="status"
        data-testid="enquiry-success"
      >
        <CheckCircle2 className="h-12 w-12 text-[#173F35]" aria-hidden="true" />
        <h3 className="font-display text-2xl text-[#17201F]">Enquiry sent</h3>
        <p className="max-w-sm text-[15px] text-[#687572]">
          Thank you, {form.name.split(" ")[0]}. Your enquiry has been received — the team
          will get back to you. For a faster reply, call or WhatsApp us on {site.phone}.
        </p>
        <button
          type="button"
          className="btn-primary"
          onClick={() => {
            setStatus("idle");
            setForm({ name: "", arrivalDate: "", departureDate: "", guests: "", roomPreference: "", message: "" });
          }}
          data-testid="enquiry-send-another"
        >
          Send another enquiry
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} noValidate className="card-ee space-y-5 p-6 sm:p-8" data-testid="booking-enquiry-form">
      <div className="grid gap-5 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label htmlFor="f-name" className="mb-1.5 block text-sm font-medium text-[#17201F]">
            Name <span aria-hidden="true" className="text-[#C88A3D]">*</span>
          </label>
          <input
            id="f-name"
            type="text"
            value={form.name}
            onChange={set("name")}
            className={inputCls}
            placeholder="Your full name"
            autoComplete="name"
            aria-invalid={!!errors.name}
            aria-describedby={errors.name ? "f-name-err" : undefined}
            data-testid="form-name-input"
          />
          {errors.name && (
            <p id="f-name-err" role="alert" className="mt-1.5 text-sm text-red-700" data-testid="form-name-error">
              {errors.name}
            </p>
          )}
        </div>
        <div>
          <label htmlFor="f-arrival" className="mb-1.5 block text-sm font-medium text-[#17201F]">
            Arrival Date
          </label>
          <input id="f-arrival" type="date" value={form.arrivalDate} onChange={set("arrivalDate")} className={inputCls} data-testid="form-arrival-input" />
        </div>
        <div>
          <label htmlFor="f-departure" className="mb-1.5 block text-sm font-medium text-[#17201F]">
            Departure Date
          </label>
          <input
            id="f-departure"
            type="date"
            value={form.departureDate}
            onChange={set("departureDate")}
            className={inputCls}
            aria-invalid={!!errors.departureDate}
            aria-describedby={errors.departureDate ? "f-dep-err" : undefined}
            data-testid="form-departure-input"
          />
          {errors.departureDate && (
            <p id="f-dep-err" role="alert" className="mt-1.5 text-sm text-red-700" data-testid="form-departure-error">
              {errors.departureDate}
            </p>
          )}
        </div>
        <div>
          <label htmlFor="f-guests" className="mb-1.5 block text-sm font-medium text-[#17201F]">
            Guests
          </label>
          <select id="f-guests" value={form.guests} onChange={set("guests")} className={inputCls} data-testid="form-guests-select">
            <option value="">Select guests</option>
            {[1, 2, 3, 4, 5, "6+"].map((g) => (
              <option key={g} value={g}>{g}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="f-room" className="mb-1.5 block text-sm font-medium text-[#17201F]">
            Room Preference
          </label>
          <select id="f-room" value={form.roomPreference} onChange={set("roomPreference")} className={inputCls} data-testid="form-room-select">
            <option value="">No preference</option>
            {rooms.map((r) => (
              <option key={r.name} value={r.name}>{r.name}</option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="f-message" className="mb-1.5 block text-sm font-medium text-[#17201F]">
            Message
          </label>
          <textarea
            id="f-message"
            rows={4}
            value={form.message}
            onChange={set("message")}
            className={`${inputCls} min-h-[120px] resize-y`}
            placeholder="Anything we should know — arrival time, dietary needs, route plans…"
            data-testid="form-message-input"
          />
        </div>
      </div>

      {status === "error" && (
        <div role="alert" className="flex items-start gap-2 rounded-xl bg-red-50 p-4 text-sm text-red-800" data-testid="enquiry-error">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
          Something went wrong sending your enquiry. Please try again, or reach us directly
          on {site.phone} / WhatsApp.
        </div>
      )}

      <button
        type="submit"
        disabled={status === "loading"}
        className="btn-primary w-full disabled:opacity-70"
        data-testid="form-submit-button"
      >
        {status === "loading" ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Sending…
          </>
        ) : (
          "Send Enquiry"
        )}
      </button>
      <p className="text-center text-xs text-[#687572]">
        This form sends an enquiry to the hotel team — it does not confirm a booking.
      </p>
    </form>
  );
};
