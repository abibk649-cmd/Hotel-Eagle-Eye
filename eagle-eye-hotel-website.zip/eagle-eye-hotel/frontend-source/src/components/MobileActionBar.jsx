import { Phone, MessageCircle, MapPin } from "lucide-react";
import { site } from "../data/siteData";

const actions = [
  { label: "CALL", href: site.phoneHref, icon: Phone, testid: "mobile-action-call", external: false },
  { label: "WHATSAPP", href: site.whatsappUrl, icon: MessageCircle, testid: "mobile-action-whatsapp", external: true },
  { label: "DIRECTIONS", href: site.googleMapsUrl, icon: MapPin, testid: "mobile-action-directions", external: true },
];

export const MobileActionBar = () => (
  <nav
    className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-3 border-t border-white/10 bg-[#173F35] md:hidden"
    aria-label="Quick contact actions"
    data-testid="mobile-action-bar"
    style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
  >
    {actions.map(({ label, href, icon: Icon, testid, external }) => (
      <a
        key={label}
        href={href}
        {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
        className="flex min-h-[56px] flex-col items-center justify-center gap-1 text-[11px] font-semibold tracking-[0.14em] text-white transition-colors active:bg-[#0F3028]"
        data-testid={testid}
      >
        <Icon className="h-5 w-5 text-[#C88A3D]" aria-hidden="true" />
        {label}
      </a>
    ))}
  </nav>
);
