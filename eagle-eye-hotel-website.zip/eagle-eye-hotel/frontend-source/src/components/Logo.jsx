export const LogoMark = ({ size = 40 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    aria-hidden="true"
    className="shrink-0"
  >
    <rect width="64" height="64" rx="14" fill="rgba(255,255,255,0.08)" />
    <path d="M10 40 L26 22 L34 31 L42 20 L54 40 Z" fill="#F7F5F0" />
    <circle cx="42" cy="16" r="5" fill="#C88A3D" />
    <ellipse cx="32" cy="45" rx="16" ry="6" fill="none" stroke="#C88A3D" strokeWidth="2.5" />
    <circle cx="32" cy="45" r="2.6" fill="#C88A3D" />
  </svg>
);

export const Logo = ({ light = false }) => (
  <span className="flex items-center gap-3" data-testid="site-logo">
    <LogoMark />
    <span className="leading-none">
      <span
        className={`font-display block text-xl tracking-wide ${
          light ? "text-white" : "text-[#17201F]"
        }`}
      >
        EAGLE EYE
      </span>
      <span
        className={`block text-[10px] font-semibold uppercase tracking-[0.3em] ${
          light ? "text-[#C88A3D]" : "text-[#687572]"
        }`}
      >
        Hotel &amp; Restaurant
      </span>
    </span>
  </span>
);
