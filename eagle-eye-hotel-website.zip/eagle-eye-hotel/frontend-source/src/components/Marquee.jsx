export const Marquee = ({ items, className = "" }) => {
  const row = [...items, ...items, ...items, ...items];
  return (
    <div
      className={`overflow-hidden border-y border-[#173F35]/10 py-5 ${className}`}
      aria-hidden="true"
      data-testid="route-marquee"
    >
      <div className="marquee-track items-center gap-10">
        {[0, 1].map((half) => (
          <div key={half} className="flex items-center gap-10 pr-10">
            {row.map((item, i) => (
              <span key={`${half}-${i}`} className="flex items-center gap-10 whitespace-nowrap">
                <span className="font-display text-2xl text-[#173F35]/70 sm:text-3xl">{item}</span>
                <svg width="26" height="14" viewBox="0 0 26 14" fill="none" aria-hidden="true">
                  <path d="M1 13 L8 3 L13 9 L18 1 L25 13 Z" stroke="#C88A3D" strokeWidth="1.6" fill="none" />
                </svg>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};
