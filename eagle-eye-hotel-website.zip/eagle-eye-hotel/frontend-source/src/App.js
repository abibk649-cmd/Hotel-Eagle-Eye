import { useEffect, useRef } from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Lenis from "lenis";
import "@/App.css";
import { AnnouncementBar } from "@/components/AnnouncementBar";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { MobileActionBar } from "@/components/MobileActionBar";
import Home from "@/pages/Home";
import Stay from "@/pages/Stay";
import Restaurant from "@/pages/Restaurant";
import Gallery from "@/pages/Gallery";
import Contact from "@/pages/Contact";

const ScrollManager = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [pathname]);
  return null;
};

const SmoothScroll = ({ children }) => {
  const lenisRef = useRef(null);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return undefined;
    const lenis = new Lenis({ duration: 1.05, smoothWheel: true });
    lenisRef.current = lenis;
    let rafId;
    const raf = (time) => {
      lenis.raf(time);
      rafId = requestAnimationFrame(raf);
    };
    rafId = requestAnimationFrame(raf);
    return () => {
      cancelAnimationFrame(rafId);
      lenis.destroy();
    };
  }, []);

  return children;
};

const Layout = () => (
  <>
    <AnnouncementBar />
    <Navbar />
    <main id="main-content">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/stay" element={<Stay />} />
        <Route path="/restaurant" element={<Restaurant />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </main>
    <Footer />
    <MobileActionBar />
  </>
);

function App() {
  return (
    <div className="App">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-[#C88A3D] focus:px-5 focus:py-2 focus:text-sm focus:font-semibold focus:text-[#17201F]"
        data-testid="skip-to-content"
      >
        Skip to content
      </a>
      <BrowserRouter>
        <ScrollManager />
        <SmoothScroll>
          <Layout />
        </SmoothScroll>
      </BrowserRouter>
    </div>
  );
}

export default App;
