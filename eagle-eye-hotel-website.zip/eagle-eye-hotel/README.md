# Eagle Eye Hotel — Website Deployment Package

Production build of the Eagle Eye Hotel website (Chame, Manang, Nepal).

## Package contents

```
eagle-eye-hotel/
├── frontend/          # Static production build — serve these files as the website
│   ├── Dockerfile     # Optional: nginx container for the frontend
│   └── nginx.conf     # SPA + /api proxy config used by the Docker setup
├── backend/           # FastAPI enquiry API (receives the contact form)
│   ├── server.py
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend-source/   # React source code — edit business data here and rebuild
├── docker-compose.yml # Easiest option: full stack in one command
└── README.md
```

---

## Option A — Docker Compose (recommended, one command)

Requires Docker + Docker Compose on your server.

```bash
cd eagle-eye-hotel
docker compose up -d --build
```

The site is then live on port 80 of your server. This starts:

- **mongo** — database for enquiry form submissions
- **backend** — FastAPI on internal port 8001
- **web** — nginx serving the static frontend on port 80, proxying `/api/*` to the backend

Point your domain's DNS A-record at the server and you're done. For HTTPS, put
Certbot/Let's Encrypt or your existing reverse proxy (Traefik, Caddy, Cloudflare)
in front of port 80.

## Option B — Manual hosting

### 1. Frontend (static files)

Upload everything inside `frontend/` (except `Dockerfile`/`nginx.conf`) to any
static host or your web server's document root (nginx, Apache, cPanel, Netlify…).

It is a single-page app, so configure a fallback to `index.html` for unknown paths:

```nginx
location / {
    try_files $uri $uri/ /index.html;
}
```

### 2. Backend (enquiry form API)

Needs Python 3.11+ and MongoDB.

```bash
cd backend
cp .env.example .env      # then edit .env with your MongoDB connection
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001
```

Proxy `/api/*` from your web server to the backend so the enquiry form works:

```nginx
location /api/ {
    proxy_pass http://127.0.0.1:8001;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}
```

Verify: `curl -X POST https://yourdomain.com/api/enquiries -H "Content-Type: application/json" -d '{"name":"Test"}'` should return JSON.

---

## HTTPS with Certbot / Let's Encrypt (free SSL)

Prerequisites: your domain's DNS A-record already points at the server, and ports
80 + 443 are open in the firewall.

The cleanest setup is: Let Docker Compose serve the site on port **8080**, and let a
small nginx on the host handle HTTPS and forward traffic to it. Certbot then manages
certificates and renewals automatically.

### 1. Run the app on port 8080

Edit `docker-compose.yml`, changing the web service ports to:

```yaml
  web:
    ports:
      - "127.0.0.1:8080:80"
```

Then start the stack:

```bash
docker compose up -d --build
```

### 2. Install nginx + Certbot on the host (Ubuntu/Debian)

```bash
sudo apt update
sudo apt install -y nginx certbot python3-certbot-nginx
```

### 3. Create the host nginx site

Create `/etc/nginx/sites-available/eagle-eye-hotel`:

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable it:

```bash
sudo ln -s /etc/nginx/sites-available/eagle-eye-hotel /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

### 4. Issue the certificate

```bash
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

Certbot edits the nginx config for you: HTTP now redirects to HTTPS automatically.

### 5. Renewal (automatic)

Certbot installs a renewal timer — nothing else to do. Verify with:

```bash
sudo certbot renew --dry-run
```

Your site now loads securely at `https://yourdomain.com`, and the enquiry form works
over HTTPS unchanged (it posts to `/api/enquiries` on the same domain).

> Alternative: if you deployed with Option B (manual hosting), your web server already
> serves the site directly — skip steps 1–3, just run `sudo apt install certbot
> python3-certbot-nginx` and then `sudo certbot --nginx -d yourdomain.com`.

---

## Editing business information

All hotel details (phone, WhatsApp, address, rooms, menu, reviews, gallery, FAQ,
Google Maps links, opening hours) live in ONE file:

```
frontend-source/src/data/siteData.js
```

Values marked `[OWNER TO CONFIRM]` are placeholders to replace with real data.

After editing, rebuild:

```bash
cd frontend-source
yarn install
yarn build
# replace your hosted frontend files with the new build/ output
```

## Replacing images

All current photos are licensed stock placeholders. Replace the image URLs in
`frontend-source/src/data/siteData.js` with the hotel's own photography
(host the images yourself or use any image host) and rebuild.

## Notes

- Fonts (DM Serif Display, Inter) load from Google Fonts CDN.
- The enquiry form POSTs to `/api/enquiries` on the same domain — no
  hardcoded external URLs, so the build works on any domain without rebuilding.
- No authentication is used anywhere on the site.
